#include<stdio.h>

#if 0
int main(void)
{
	int x=10;
	int y=15;
	printf("Addition of x & y is :%d\n", x+y);
	printf("Subtraction of x & y is :%d\n",x-y);
	printf("Multiplication of x & y is:%d\n",x*y);
	printf("Divison of x & y is:%d\n", x/y);
	printf("Modulo division of x & y is:%d\n", x%y);
	return 0;
}
#endif

#if 0
int main(void)
{
	char x=10;
	char y=15;
	printf("Addition of x & y is :%d\n", x+y);
	printf("Subtraction of x & y is :%d\n",x-y);
	printf("Multiplication of x & y is:%d\n",x*y);
	printf("Divison of x & y is:%d\n", x/y);
	printf("Modulo division of x & y is:%d\n", x%y);
	return 0;
}
#endif

#if 0
int main(void)
{
	float x=10;
	float y=15;
	printf("Addition of x & y is :%f\n", x+y);
	printf("Subtraction of x & y is :%f\n",x-y);
	printf("Multiplication of x & y is:%f\n",x*y);
	printf("Divison of x & y is:%f\n", x/y);
	printf("Modulo division of x & y is:%f\n", x%y);
	return 0;
}
#endif

#if 1

int main(void)
{
	double x=1;
	double y=15;
	printf("Addition of x & y is :%lf\n", x+y);
	printf("Subtraction of x & y is :%lf\n",x-y);
	printf("Multiplication of x & y is:%lf\n",x*y);
	printf("Divison of x & y is:%lf\n", x/y);
	printf("Modulo division of x & y is:%lf\n", x%y);
	return 0;
}
#endif
