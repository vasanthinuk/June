#include<stdio.h>

int add(int, int);//function declaration

int main()
{
	int a;
	int b;
	int c;
	int (*ip)(int, int);//function pointer declaration
	printf("Enter a:");
	scanf("%d", &a);
	printf("Enter b:");
	scanf("%d", &b);
	ip = add;
	c = (*ip)(a, b);
	printf("%d", c);
	return 0;
}

int add(int a, int b)
{
	return a+b;//returning sum of 2 numbers
}
