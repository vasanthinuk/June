#include<stdio.h>

int *fun();

int main()
{
	int *p = fun();
	printf("%d", *p);
	return 0;
}

int *fun()
{
	static int y = 10;
	return &y;
}

