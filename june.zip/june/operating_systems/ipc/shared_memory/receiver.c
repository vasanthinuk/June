#include<stdio.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<string.h>
#include<sys/mman.h>
#include<fcntl.h>
#include<unistd.h>

#define SIZE 4096


int main()
{
	int shd;//shared memory file descriptor
	char msg[SIZE];//data written variable

	char *a;

	shd = shm_open("/shm",O_RDONLY,0666);//shared memory creating
	if(shd < 0)//checking whether the shared memory created or not
	{
		perror("Error:");
		exit(1);
	}

	
	a = mmap(0,SIZE,PROT_READ,MAP_SHARED,shd,0);

	if(a == MAP_FAILED)
	{
		perror("Error:");
		exit(1);
	}
	
	printf("The message is:%s\n", (char*)a);

	if(munmap(a,1) == -1)
	{
		perror("Error:");
		exit(1);
	}


	close(shd);
	return 0;
}
