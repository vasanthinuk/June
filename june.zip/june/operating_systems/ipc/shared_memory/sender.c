#include<stdio.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<string.h>
#include<sys/mman.h>
#include<fcntl.h>
#include<unistd.h>

#define SIZE 4096


int main()
{
	int shd;//shared memory file descriptor
	char msg[SIZE];//data written variable

	char *a;

	shd = shm_open("/shm",O_CREAT|O_RDWR,0666);//shared memory creating
	if(shd < 0)//checking whether the shared memory created or not
	{
		perror("Error:");
		exit(1);
	}
	if((ftruncate(shd,SIZE)) < 0)//fixing the size to shared memory
	{
		perror("Error:");
		exit(1);
	}
	
	a = mmap(0,SIZE,PROT_WRITE,MAP_SHARED,shd,0);

	if(a == MAP_FAILED)
	{
		perror("Error:");
		exit(1);
	}

	printf("Enter the message for a program to write data into it:");
	fgets(msg,SIZE,stdin);
	msg[strlen(msg) -1]= '\0';

	memcpy(a,msg,strlen(msg));
	printf("The entered msg is:%s\n",msg);

	close(shd);//closing of shared memory descriptor

	return 0;
}
	
	

