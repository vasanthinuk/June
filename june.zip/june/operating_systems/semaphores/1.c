/*program for process synchronization using semaphores
program create two threads:one is incrementing the value of shared variable and other is used to decrement the value of shared variable*/

#include<stdio.h>
#include<semaphore.h>
#include<pthread.h>
#include<unistd.h>

void* fun1();
void* fun2();

int shared = 1;
sem_t s;//creating a shared variable

int main()
{
	sem_init(&s,0,1);//initialize semaphore variable-1st argument is address of semaphore variable,2nd -//processes sharing semaphores,3rd - initial value of semaphore
	pthread_t t1;
	pthread_t t2;
	pthread_create(&t1,NULL,fun1,NULL);
	pthread_create(&t2,NULL,fun2,NULL);
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
	printf("Final value of shared variable is %d\n",shared);
	return 0;
}

void* fun1()
{
	int x;
	sem_wait(&s);//executes wait operation on s
	x = shared;
	printf("The value of x is:%d\n",x);
	x++;//threads value incremented by 1
	printf("Thread updated value is:%d\n",x);
	sleep(1);//preempted by thread 2
	shared = x;
	printf("Value of shared variable after updated by thread is:%d\n",shared);
	sem_post(&s);//used to unlock a semaphore
}

void* fun2()
{
	int y;
	sem_wait(&s);//executes wait operation on s
	y = shared;
	printf("The value of y is:%d\n",y);
	y--;//threads value incremented by 1
	printf("Thread updated value of y is:%d\n",y);
	sleep(1);//preempted by thread1
	shared = y;
	printf("Value of shared variable after updated by thread y is:%d\n",shared);
	sem_post(&s);//used to unlock a semaphore
}


