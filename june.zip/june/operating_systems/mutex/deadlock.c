#include<stdio.h>
#include<pthread.h>
#include<unistd.h>

pthread_mutex_t p1;
pthread_mutex_t p2;

void* fun1();
void* fun2();

int main()
{
	pthread_mutex_init(&p1,NULL);
	pthread_mutex_init(&p2,NULL);
	pthread_t t1;
	pthread_t t2;
	pthread_create(&t1,NULL,fun1,NULL);
	pthread_create(&t2,NULL,fun2,NULL);
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
	printf("Thread joined\n");
	return 0;
}

void* fun1()
{
	printf("T1 trying to acquire first mutex\n");
	pthread_mutex_lock(&p1);
	printf("T1 acquired p1 mutex\n");
	sleep(1);
	printf("T1 trying to acquire second mutex\n");
	pthread_mutex_lock(&p2);
	printf("T1 acquired second mutex\n");
	pthread_mutex_unlock(&p1);
}

void* fun2()
{
	printf("T2 trying to acquire first mutex\n");
	pthread_mutex_lock(&p2);
	printf("T2 acquired p1 mutex\n");
	sleep(1);
	printf("T2 trying to acquire second mutex\n");
	pthread_mutex_lock(&p1);
	printf("T2 acquired second mutex\n");
	pthread_mutex_unlock(&p2);
}
