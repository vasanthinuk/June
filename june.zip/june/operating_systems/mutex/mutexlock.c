#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
#include<stdlib.h>

void* fun1();
void* fun2();

int shared = 2;
pthread_mutex_t p;//globally declared mutex variable

int main()
{
	pthread_mutex_init(&p,NULL);//initialize the locks
	pthread_t t1;
	pthread_t t2;
	pthread_create(&t1,NULL,fun1,NULL);
	pthread_create(&t2,NULL,fun2,NULL);
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
	printf("Final value of shared variable is:%d\n",shared);
	return 0;
}

void* fun1()
{
	int a;
	printf("Thread1 trying to acquire the lock\n");
	pthread_mutex_lock(&p);//thread1 acquires the lock nd now thread 2 will not be able to acquire the lock,untill is unclocked by thread1
	printf("Thread1 acquired lock\n");
	a = shared;
	printf("T1 reads the value of shared variable as %d\n",a);
	a++;
	printf("Local updation for t1:%d\n",a);
	sleep(1);
	shared = a;
	printf("Value of shared variable updated by thread1:%d\n",shared);
	pthread_mutex_unlock(&p);
	printf("T1 released the lock\n");
}


void* fun2()
{
	int b;
	printf("Thread1 trying to acquire the lock\n");
	pthread_mutex_lock(&p);//thread1 acquires the lock nd now thread 2 will not be able to acquire the lock,untill is unclocked by thread1
	printf("Thread1 acquired lock\n");
	b = shared;
	printf("T1 reads the value of shared variable as %d\n",b);
	b--;
	printf("Local updation for t1:%d\n",b);
	sleep(1);
	shared = b;
	printf("Value of shared variable updated by thread1:%d\n",shared);
	pthread_mutex_unlock(&p);
	printf("T2 released the lock\n");
}
