#include<stdio.h>
#include<pthread.h>
#include<unistd.h>

void* thread_function(void *arg);

int main()
{
	pthread_t thread;//creating a thread variable 
	pthread_create(&thread,NULL, thread_function,NULL);
	pthread_join(thread,NULL);
	printf("Inside main thread\n");
	for(char i = 'a'; i < 'z'; i++)
	{
		printf("%c\n",i);
		sleep(1);
	}
	return 0;
}

void* thread_function(void *arg)
{
	printf("Inside function thread\n");
	printf("The thread id is %d\n",getpid());
	for(int j = 5;j < 10; j++)
	{
		printf("%d\n",j);
		sleep(1);
	}
	printf("pthread self is:%ld\n",pthread_self());
}
