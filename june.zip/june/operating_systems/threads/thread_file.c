#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<string.h>
#include<fcntl.h>

void* T1_fun(void *arg);
void* T2_fun(void *arg);

int fd;

int main()
{
	pthread_t t1;
	pthread_t t2;
	pthread_create(&t1,NULL,T1_fun,NULL);
	pthread_join(t1,NULL);
	pthread_create(&t2,NULL,T2_fun,NULL);
	pthread_join(t2,NULL);
	return 0;
}

void* T1_fun(void *arg)
{
	fd = open("Thread.txt",O_CREAT,0777);
	printf("Thread.txt file created by T1\n");
	close(fd);
}

void* T2_fun(void *arg)
{
	fd = open("Thread.txt",O_WRONLY);
	write(fd,"HEllo its T2",12);
	close(fd);
}
