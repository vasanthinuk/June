#include<stdio.h>
#include<pthread.h>
#include<unistd.h>

void* fun1();
void* fun2();

int shared = 1;
int main()
{
	pthread_t thread;//creating a thread variable 
	pthread_t t2;
	pthread_create(&thread,NULL, fun1,NULL);
	//pthread_join(thread,NULL);
	pthread_create(&t2,NULL,fun2,NULL);
	pthread_join(thread,NULL);
	pthread_join(t2,NULL);
	printf("Inside main thread\n");
	printf("Final value of shared is %d\n",shared);
	return 0;
}

void* fun1()
{
	int x;
	x = shared;
	printf("Value of x is:%d\n",x);
	x++;
	printf("Local value for shared variable is:%d\n",x);
	sleep(1);
	shared = x;
	printf("Value of shared variable updated by thread1 is:%d\n",shared);

}

void* fun2()
{
	int y;
	y = shared;
	printf("Value of y is:%d\n",y);;
	y--;
	printf("Local value for shared variable is:%d\n",y);
	sleep(1);
	shared = y;
	printf("Value of shared variable updated by thread1 is:%d\n",shared);;

}
