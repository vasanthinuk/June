#include<stdio.h>
#include<pthread.h>
#include<unistd.h>

void* thread_function(void *arg);
int arr[5] = {10,20,30,40,50};
int main()
{
	pthread_t thread;//creating a thread variable 
	void *result;
	pthread_create(&thread,NULL, thread_function,(void*)arr);
	pthread_join(thread,&result);
	printf("Inside main program\n");
	for(char i = 'a'; i < 'z'; i++)
	{
		printf("%c\n",i);
		sleep(1);
	}
	printf("Thread returned is:%s\n",(char*)result);
	return 0;
}

void* thread_function(void *arg)
{
	int sum = 0;
	printf("Inside function thread\n");
	printf("The thread id is %d\n",getpid());
	for(int j = 0;j < 5; j++)
	{
		sum = sum + arr[j];
		sleep(1);
	}
	printf("%d\n",sum);
	pthread_exit("Successfully completed");
}
