#include<stdio.h>

static int a = 10;
void fun();

int main()
{
	fun();
	fun();
	fun();
	return 0;
}

void fun()
{
	printf("%d\n",a);
	a++;
}
