#include<stdio.h>

static int a = 10;
static char b ='A';
extern int c = 15;
//float d = 12.3;
void fun1();
void fun2();
void fun3();
void fun4();

int main()
{
	fun1();
	fun2();
	fun3();
	fun4();
	return 2;
}
float d = 12.4;
void fun1()
{
	printf("Value of a:%d\n",a);
	printf("Value of b:%c\n",b);
	printf("Value of c:%d\n",c);
	printf("Value of d:%f\n",d);
}

void fun2()
{
	printf("%d\n",a);
	printf("%c\n",b);
}

void fun3()
{
	printf("%c\n",b);
	printf("%d\n",c);
}

void fun4()
{
	printf("%d\n",c);
	printf("%f\n",d);
}
