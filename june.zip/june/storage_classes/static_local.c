#include<stdio.h>

void fun();

int main()
{
	fun();//whenever we calling the function it is created and initialized
	fun();
	return 0;
}

void fun()
{
	static int x = 10;//by default it is automatic variables ,local variable declaration
	static int y = 12;
	printf("Values of x & y is: %d %d\n", x, y);
	x++;
	y++;
}
