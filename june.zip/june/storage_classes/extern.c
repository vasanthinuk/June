#include<stdio.h>
int a = 10;
int b = 2;
int x = 13;
extern int  c;
extern int d = 15;
void fun1();
void fun2();

int main()
{
	
	int y = 3;
	{
		printf("The value of y is :%d\n", y);
		int z = 6;
	}
	printf("Value of d is:%d\n",d);
	fun1();
	fun2();
	return 0;
}

void fun1()
{
	extern int  x;
	printf("Value of x is:%d\n", x);
	printf("Value of a is:%d\n",a);
}


c = 14;
void fun2()
{
	 extern  int b;
	printf("Value of a:%d\n",b);
	printf("%d",c);
	
}
