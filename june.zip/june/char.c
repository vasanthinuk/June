#include<stdio.h>

int main(void)
{
	int num;
	for(num=65;num<=90;num++)
	{
		printf("%c\n", (char)num);
	}
	return 0;
}
