#include<stdio.h>

int main(void)
{
	int x=23;
	printf("The octal value of x is :%o\n",x);
	printf("The hexadecimal value of x is: %x\n",x);
	return 0;
}
