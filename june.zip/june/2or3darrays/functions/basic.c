#include<stdio.h>

void display(int , int );

int main()
{
	int arr[] = {10, 20, 30, 40};
	display(arr[1], arr[2]);
	return 0;
}

void display(int a, int b)
{
	printf("%d\n", a);
	printf("%d\n", b);
}
