#include<stdio.h>

int sum_array(int arr[], int n);

int main()
{
	int arr1[30];
	int n;
	int sum;
	printf("Enter number of elements to be entered:");
	scanf("%d", &n);
	for(int i = 0; i < n; i++)
	{
		scanf("%d", &arr1[i]);
	}

	 sum =sum_array(arr1, n);
	 printf("The sum of array is:%d", sum);
	return 0;
}

int sum_array(int arr[], int n)
{
	int sum = 0;
	for(int i = 0; i < n;i++)
	{
		sum = sum +arr[i];
	}
	return sum;
}
