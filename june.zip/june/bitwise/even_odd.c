#include<stdio.h>

int main()
{
	unsigned int num;
	printf("Enter a number:");
	scanf("%u", &num);
	if((num & 1) == 0)
	{
		printf("Even");
	}
	else
	{
		printf("Odd");
	}
	return 0;
}
