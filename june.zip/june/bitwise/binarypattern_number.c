#include<stdio.h>

unsigned int bit_pattern(unsigned int);

int main()
{
	unsigned int num;
	printf("Enter a number:");
	scanf("%u", &num);
	bit_pattern(num);
	printf("%d", sizeof(bit_pattern(num)));
	return 0;
}

unsigned int bit_pattern(unsigned int num)
{
	int mask;

	for(int i = 32; i >= 0; i--)
	{
		mask = 1<<i;
		if((num & mask)==0) 
		{
			printf("0");
		}
		else
		{
			printf("1");
		}
	}
	printf("\n");
}
		

