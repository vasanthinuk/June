#include<stdio.h>

int main()
{
	unsigned int num ;
	//unsigned int num1;
	printf("Enter a hexadecimal value:");
	scanf("%x", &num);
	num = ((num >> 8) & 0x00FF) | (num << 8) & 0xFF00;
	//num1 = num << 24;
	printf("%x", num);
	return 0;
}
