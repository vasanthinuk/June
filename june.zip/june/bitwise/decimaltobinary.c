#include<stdio.h>

void getBinary(int);

int main()
{
	int num;
	printf("Enter a decimal number:");
	scanf("%d",&num);
	getBinary(num);
	return 0;
}

void getBinary(int num)
{
	for(int i = 31; i>=0;i--)
	{
		if((1<<i)&num)
		{
			printf("1");
		
		}
		else
		{
			printf("0");
			
		}
	}
}
