#include<stdio.h>

int countsetBits(int);

int main()
{
	int num;
	printf("Enter a number:");
	scanf("%d",&num);
	printf("The count of set bits is:%d\n",countsetBits(num));
	return 0;
}

int countsetBits(int n)
{
	int count = 0;
	for(int i = 0; i<32; i++)
	{
		if((1<<i)&n)
		{
			count++;
		
		}
	}
	return count;
}

