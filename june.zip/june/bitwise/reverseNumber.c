#include<stdio.h>

unsigned int revNum(unsigned int);

int main()
{
	unsigned int num;
	printf("Enter a number:");
	scanf("%d",&num);
	printf("%u",revNum(num));
	return 0;
}

unsigned int revNum(unsigned int num)
{
	unsigned int temp;
	for(int i = 0; i < 32; i++)
	{
		temp = ((1<<i)&num);
		if(temp)
		{
			revNum |= ((1<<(32 -1)-i));
		}
		return revNum;
	}
}
