#include<stdio.h>

int main()
{
	int num = 0xABCD;
	num =((num << 8) & 0xFF00) | ((num >> 8)&0x00FF);
	printf("%x",num);
}

