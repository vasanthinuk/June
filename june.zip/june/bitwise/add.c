
#include<stdio.h>

unsigned int addition(unsigned int, unsigned int);

int main()
{
	unsigned int n1;
	unsigned int n2;
	unsigned int res;
	printf("Enter 1st number");
	scanf("%u",&n1);
	printf("Enter 2nd number");
	scanf("%u",&n2);
	res = addition(n1, n2);
	printf("Addition of two numbers is:%u",res);
	return 0;
}

unsigned int carry = 0;
unsigned int addition(unsigned int a, unsigned int b)
{
	while(b != 0)
	{
		carry = a & b;
		a = a ^ b;
		b = carry << 1;
	}
	return a;
}



