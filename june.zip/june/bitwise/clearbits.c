#include<stdio.h>

void clearBits(int);

int main()
{
	int num;
	printf("Enter a number:");
	scanf("%d",&num);
	clearBits(num);
	return 0;
}

void clearBits(int n)
{
	int count = 0;
	for(int i = 0; i<32; i++)
	{
		if((1<<i)&n)
		{
			count = 1;
			break;
		}
	}
	if(count == 0)
	{
		printf("All bits are set to 0 ");
	}
	else
	{
		printf("All bits are unset");
	}
}

