#include<stdio.h>

int countBits(int);

int main()
{
	int num;
	printf("Enter a decimal number:");
	scanf("%d",&num);
	printf("The Bits required for number is:%d\n",countBits(num));
	return 0;
}

int countBits(int num)
{
	int count = 0;
	int i;
	if(num == 0)
	{
		return 0;
	}
	for(i = 0; i<32;i++)
	{
		if((1<<i)&num)
		{
			count = i;
		
		}
	}
	return ++count;
}
