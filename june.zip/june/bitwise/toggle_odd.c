/*
* * Name 	: toggle_even.c
* * Description : This program is used to toggle the even bits
* * Date   	: 26-06-2023
* */

#include<stdio.h>

int main(void)
{
	unsigned char num;
	printf("Enter a number");
	scanf("%hhu",&num);
	num = num ^ 0x55;
	printf("%hhu", num);
	return 0;
}
