#include<stdio.h>

int main(void)
{
	int n1;
	int n2;
	int res = 0;
	printf("Enter n1 and n2 values:");
	scanf("%d  %d",&n1,&n2);
	while(n2 > 0)
	{
		if (n2 & 1)
		{
			res = res + n1;
		}
		n1 <<=1;
		n2 >>=1;
	}
	printf("The multiplication of n1 and n2 is:%d\n",res);
	return 0;
}


