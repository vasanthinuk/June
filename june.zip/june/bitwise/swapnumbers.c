#include<stdio.h>
int swapNumber(int*,int*);


int main()
{
	int n1;
	int n2;
	int res;
	printf("Enter n1 and n2 values:");
	scanf("%d %d",&n1,&n2);
	printf("Before swapping of two numbers is:%d %d\n",n1,n2);
	swapNumber(&n1,&n2);
	printf("After swapping of two numbers is:%d %d\n",n1,n2);
	return 0;
}

int swapNumber(int* a,int* b)
{
	*a = *a ^ *b;
	*b = *a ^ *b;
	*a = *a ^ *b;
}
