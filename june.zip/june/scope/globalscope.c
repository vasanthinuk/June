#include<stdio.h>

int num = 100;
 
void fun();

int main()
{
	printf("The value of num is : %d\n", num);
	fun();
	return 0;
}

void fun()
{
	printf("The value of num is : %d\n", num);
}

