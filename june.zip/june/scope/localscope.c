#include<stdio.h>

int main()
{
	int a = 10;
	{
		int b = 20;
		printf("The value of b is :%d\n", b);
		printf("The value of a is :%d\n", a);
	}
	//printf("The value of b is : %d", b);
	return 0;
}
