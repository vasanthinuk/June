#include<stdio.h>
#include<string.h>

enum days{mon,tue,wed,thu,fri,sat,sun};

int main()
{
	enum days day;
	day = sun;
	printf("%d\n", day);
}
