#include<stdio.h>

enum values{A='A',vasu };
int main()
{
	enum values v;
	v = vasu;
	printf("%d",v);
}
