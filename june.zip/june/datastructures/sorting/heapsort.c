#include<stdio.h>

void heapify(int arr[],int n,int i);
void heapsort(int arr[],int n);

int main()
{
	int arr[50];
	int n;
	printf("Enter the size of an array:");
	scanf("%d",&n);
	for(int i = 0; i< n;i++)
	{
		scanf("%d",&arr[i]);
	}
	printf("The elements before sorting of array are:");
	for(int i = 0; i < n; i++)
	{
		printf("%d  ",arr[i]);
	}
	printf("\n");

	heapsort(arr,n);
	printf("After applying heap sort :");
	for(int i = 0; i < n;i++)
	{
		printf("%d ",arr[i]);
	}
	printf("\n");
	return 0;
}

void heapify(int arr[],int n,int i)//to heapify the array
{
	int temp;
	int large = i;
	int l = 2*i + 1;
	int r = 2*i + 2;
	if(l < n && arr[l] > arr[large])
		large = l;
	if(r < n && arr[r] > arr[large])
		large = r;
	if(large != i)
	{
		temp = arr[i];
		arr[i] = arr[large];
		arr[large] = temp;
		heapify(arr,n,large);
	}
}

void heapsort(int arr[],int n)
{
	int temp;
	for(int i = n/2 -1;i>=0;i--)
	{
		heapify(arr,n,i);
	}

	for(int i = n-1; i>=0; i--)
	{
		temp = arr[0];
		arr[0] = arr[i];
		arr[i] = temp;
		heapify(arr, i, 0);
	}
}

