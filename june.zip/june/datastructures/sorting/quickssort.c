#include<stdio.h>

int partition(int arr[],int low,int high);
void quicksort(int arr[],int low,int high);
void printArray(int arr[],int n);

int main()
{
//	int arr[] = {12,2,45,9,0,35,7,6};
//	int size = sizeof(arr)/sizeof(arr[0]);
	
	int arr[50];
	int n;
	printf("Enter the size of array:");
	scanf("%d",&n);
	for(int i = 0; i < n; i++)
	{
		scanf("%d",&arr[i]);
	}

	printf("The array elements are:");
	printArray(arr,n);

	quicksort(arr,0,n-1);

	printf("Sorted array is:");
	printArray(arr,n);
	return 0;
}


int partition(int arr[], int low, int high)//partition of array 
{
	int pivot = arr[high];//assigning pivot as the last element
	int i = (low - 1);

	for(int j = low; j<=high-1; j++)//checking condition
	{
		if(arr[j] < pivot)//if starting element is less than the pivot then it should swap
		{
			i++;
			int t = arr[i];
			arr[i] = arr[j];
			arr[j] = t;
		}
	}
	int t = arr[i+1];
	arr[i+1] = arr[high];
	arr[high] = t;
	return(i+1);
}

void quicksort(int arr[],int low,int high)
{
	if(low < high)
	{
		int pivotind = partition(arr,low,high);
		quicksort(arr,low,pivotind-1);
		quicksort(arr,pivotind+1,high);
	}
}

void printArray(int arr[],int n)
{
	for(int i = 0; i < n; i++)
	{
		printf("%d   ",arr[i]);
	}
	printf("\n");
}
