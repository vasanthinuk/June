#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node *next;
};

void insert();
void delete();
void display();
void getMax();
void search();
void sortQueuedesc();


struct node *front;
struct node *rear;

int main()
{
	int ch;
	printf("...Queue implementation using linked list..\n");
	while(1)
	{
		printf("1.Insert\n2.Delete\n3.Display\n4.Maximum Element\n5.search\n6.Sort\n7.Exit\n");
		printf("Enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1 : insert();
				 break;
			case 2 : delete();
				 break;
			case 3 : display();
				 break;
			case 4 : getMax();
			         break;
			case 5 : search();
				 break;
			case 6 : sortQueuedesc();
				 break;
			case 7 : exit(1);
				 break;
			default : printf("Invalid choice");
		}
	}
	return 0;
}

void insert()
{
	struct node *ptr;
	int val;
	ptr = (struct node*)malloc(sizeof(struct node));
	if(ptr == NULL)
	{
		printf("Element can't be inserted\n");
	}
	else
	{
		printf("Enter value:");
		scanf("%d",&val);
		ptr -> data = val;
		if(front == NULL)
		{
			front = ptr;
			rear = ptr;
			front -> next = NULL;
			rear -> next = NULL;
		}
		else
		{
			rear-> next = ptr;
			rear = ptr;
			rear -> next = NULL;
		}
	}
}

void delete()
{
	struct node *ptr;
	if(ptr == NULL)
	{
		printf("Queue is overflow\n");
	}
	else
	{
		ptr = front;
		front = front -> next;
		free(ptr);
	}
}

void display()
{
	struct node *ptr;
	ptr = front;
	if(front == NULL)
	{	
		printf("Queue is underflow\n");
	}
	else
	{
		while(ptr != NULL)
		{
			printf("%d\n",ptr-> data);
			ptr = ptr -> next;
		}
	}
}

void getMax()
{
	int max;
	struct node *ptr = front;
	if(front == NULL)
	{
		printf("Queue is underflow\n");
	}
	else
	{
		while(ptr != NULL)
		{
			if(max < ptr -> data);
			{
				max = ptr -> data;
			}
			ptr = ptr->next;
		}
		printf("The maximum element from the queue is:%d\n", max);
	}
}


void search()
{
	struct node *ptr;
	int item;
	int count;
	int i = 0;
	ptr = front;
	if(ptr == NULL)
	{
		printf("Queue is underflow\n");
	}
	else
	{
		printf("Enter item to be searched:");
		scanf("%d",&item);
		while(ptr != NULL)
		{
			if(ptr -> data == item)
			{
				printf("searched element found:%d\n",i
				+1);
				count = 0;
			}
			else
			{
				count = 1;
			}
			i++;
			ptr = ptr -> next;
		}
		if(count == 1)
		{
			printf("Element not found\n");
		}
	}
}

void sortQueuedesc()
{
	struct node *current = front;
	struct node *index;
	int temp;
	while(current != NULL)
	{
		index = current -> next;
		while(index != NULL)
		{
			if(current -> data < index -> data)
			{
				temp = current -> data;
				current -> data = index->data;
				index -> data = temp;
			}
			index = index -> next;
		}
		current = current -> next;
	}
}
