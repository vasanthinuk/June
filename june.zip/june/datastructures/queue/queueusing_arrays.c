#include<stdio.h>
#include<stdlib.h>

#define MAXSIZE 30

int queue[MAXSIZE];
int front = -1;
int rear = -1;


void enqueue();
void dequeue();
void display();
void getMax();
void getMin();

int main()
{
	int ch;
	int n;
	printf("...Queue implementation using arrays..\n");
	//printf("Enter number of elements to be entered into queue:");
	//scanf("%d",&n);
	while(1)
	{
		printf("1.Insert\n2.Delete\n3.Display\n4.Maximum Element\n5.Mininmum Element\n6.Exit\n");
		printf("Enter your choice:");
		scanf("%d", &ch);
		switch(ch)
		{
			case 1 : enqueue();
				 break;
			case 2 : dequeue();
				 break;
			case 3 : display();
				 break;
			case 4 : getMax();
				 break;
			case 5 : getMin();
				 break;
			case 6 : exit(1);
				 break;
			default : printf("Invalid choice");
		}
	}
	
	return 0;

}

void enqueue()
{
	int ele;
	if(rear == MAXSIZE -1)
	{
		printf("Queue is full\n");
		return;
	}
	else
	{
		if(front == -1)
		front = 0;
		printf("Enter element into  queue:");
		scanf("%d",&ele);
		rear++;
		queue[rear] = ele;
	}
}

void dequeue()
{
	if(front == -1 || front > rear)
	{
		printf("Queue is empty\n");
		//return -1;
	}
	else
	{

		int element = queue[front];
		front++;
		printf("The popped element is:%d\n",element);
	}
}

void display()
{
	if(front== -1)
	{	
		printf("Queue is empty\n");
	}
	else
	{
		printf("Queue is: \n");
		for(int i = front; i <= rear; i++)
		{
			printf("%d\n",queue[i]);
		}
	}
}


void getMax()
{
	int max;
	if(front == -1 || front > rear)
	{
		printf("Queue is full\n");
	}
	else
	{
		max = queue[front];
		for(int i = front; i <= rear; i++)
		{
			if(max < queue[i])
			{	
				max = queue[i];
			}
		}
		printf("The maximum element from the queue is:%d\n", max);
	}

}

void getMin()
{
	int min;
	if(front == -1 || front > rear)
	{
		printf("Queue is full\n");
	}
	else
	{
		min = queue[front];
		for(int i = front; i <= rear; i++)
		{
			if(min > queue[i])
			{	
				min = queue[i];
			}
		}
		printf("The minimum element from the queue is:%d\n", min);
	}
	
}
