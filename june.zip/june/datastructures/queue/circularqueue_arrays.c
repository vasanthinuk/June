#include<stdio.h>
#include<stdlib.h>

#define MAX 30

int queue[MAX];
int front = -1;
int rear = -1;

void enqueue( );
void dequeue();
void display();

int main()
{
	int ch;
	printf("Implementation of Circular queue\n");
	while(1)
	{

		printf("1.Insert\n2.Delete\n3.Display\n4.Exit\n");
		printf("Enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1 : enqueue();
				 break;
			case 2 : dequeue();
				 break;
			case 3 : display();
				 break;
			case 4 : exit(1);
			 	break;
			default : printf("Invalid choice");
		}
	}
	return 0;
}

void enqueue()
{
	int ele;
	printf("Enter ele:");
	scanf("%d",&ele);
	if(front == -1 && rear == -1)
	{	
		front = 0;
		rear = 0;
		queue[rear] = ele;
	}
	else if((rear+1)%MAX == front)
	{
		printf("Queue is underflow\n");
	}
	else
	{
		//printf("Enter element:");
		//scanf("%d", &ele);
		rear =(rear+1)%MAX;
		queue[rear] = ele;
	}
}

void dequeue()
{
	if((front == -1) && (rear == -1))
	{
		printf("Queue is underflow\n");
	}
	else if(front == rear)
	{
		printf("The dequeued element is:%d\n",queue[front]);
		front = -1;
		rear = -1;
	}
	else
	{
		printf("The dequeued element is:%d\n",queue[front]);
		front = (front+1)%MAX;
	}
}

void display()
{
	int i = front;
	if(front == -1 && rear == -1)
	{
		printf("Queue is empty\n");
	}
	else
	{
		printf("Elements in Queue are:\n");
		while(i<= rear)
		{
			printf("%d\n",queue[i]);
			i =(i+1)%MAX;
		}
	}
}

