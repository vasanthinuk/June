#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node *next;
};

struct node *front = -1 ;
struct node *rear = -1 ;

void enqueue(int);
void dequeue();
void display();

int main()
{
	int ch;
	int ele;
	printf("Implementation of Circular queue using Linked list\n");
	while(1)
	{
		printf("1.Insert\n2.Delete\n3.Display\n4.Exit\n");
		printf("Enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1 : printf("Enter element into queue:");
				 scanf("%d",&ele);
				 enqueue(ele);
				 break;
			case 2 : dequeue();
				 break;
			case 3 : display();
				 break;
			case 4 : exit(1);
				 break;
			default : printf("Invalid choice\n");
		}
	}
	return 0;
}

void enqueue(int ele)
{
	struct node  *ptr;
	ptr = (struct node*)malloc(sizeof(struct node));
	ptr -> data = ele;
	ptr -> next = 0;
	if(rear == -1)
	{
		front = rear = ptr;
		rear -> next = ptr;
	}
	else
	{
		rear -> next = ptr;
		rear = ptr;
		rear -> next = front;
	}
}

void dequeue()
{
	struct node *temp;
	temp = front;
	if((front == -1) && (rear == -1))
	{
		printf("Queue is empty\n");
	}
	else if(front == rear)
	{
		front = rear = -1;
		free(temp);
	}
	else
	{
		front = front -> next;
		rear->next = front;
		free(temp);
	}
}

void display()
{
	struct node *temp;
	temp = front;
	printf("The elements in queue are:\n");
	if(front == -1 && rear == -1)
	{
		printf("Queue is empty\n");
	}
	else
	{
		while(temp-> next != front)
		{
			printf("%d ",temp->data);
			temp = temp -> next;
		}
		printf("%d \n", temp->data);
	}
}

