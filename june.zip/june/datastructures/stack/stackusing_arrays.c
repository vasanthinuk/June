#include<stdio.h>
#include<stdlib.h>

void push();
void pop();
void peek();
void getmin();
void getmax();
void display();

int stack[100];
int top = -1;
int n;
int main()
{

	int ch;
	//printf("Stack Implementation using arrays\n");
	printf("Enter number of elements to be entered into stack:");
	scanf("%d", &n);
	while(1)
	{
		printf("Stack Implementation using arrays\n");
		//printf("Enter n:");
		//scanf("%d",&n);
		printf("1.Insert Element into stack\n2.Deletion of element from stack\n3.top element from stack\n4.Display\n5.get minimum element\n6.Get maximum element\n7.Exit\n");
		printf("Enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1 : push();
			         break;
			case 2 : pop();
				 break;
			case 3 : peek();
				 break;
			case 4 : display();
				 break;	
			case 5 : getmin();
				 break;
			case 6 : getmax();
				 break;
			case 7 : exit(1);
				 break;
			default : printf("Invalid choice");
		}
	}
	return 0;
	
}

void push()
{
	int value;
	if(top > n-1)
	{
		printf("Overflow of stack\n");
	}
	else
	{
		printf("Enter value into stack:");
		scanf("%d",&value);
		top = top+1;
		stack[top] = value;
	}
}

void pop()
{
	if(top <= -1)
	{
		printf("Stack is underflow\n");
	}
	else
	{
		printf("The popped element is:%d\n",stack[top]);
		top--;
	}
}


void display()
{
	if(top >= 0)
	{
		for(int i = top; i >=0 ; i--)
		{
			printf("%d\n",stack[i]);
		}
	}
	else
	{
			printf("stack is empty\n");
	}
}

void peek()
{
	if(top == -1)
	{
		printf("Stack underflow\n");
	}
	else
	{
		printf("%d\n",stack[top]);
	}
}

void getmin()
{
	int min;
	int i;
	min = stack[0];
	if(top == -1)
	{
		printf("Stack underflow\n");
	}
	else
	{
		for(i = 0; i < n; i++)
		{
			if(stack[i] < min)
			{
				min = stack[i];
			}
		}
		printf("Minimum element is:%d\n",min);
	}
}

void getmax()
{
	int max = stack[0];
	if(top == -1)
	{
		printf("Stack underflow\n");
	}
	else
	{
		for(int i = 0; i < n; i++)
		{
			if(max < stack[i])
			{
				max = stack[i];
			}
		}
		printf("The maximum element from stack is:%d\n", max);
	}
}

