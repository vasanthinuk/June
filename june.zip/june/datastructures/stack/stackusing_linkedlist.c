#include<stdio.h>
#include<stdlib.h>

struct node//creating a node for stack
{
	int data;
	struct node *next;
};

struct node *head;

void push();
void pop();
void display();
void minElement();


int main()
{
	int ch;
	printf("...Stack operations using linked list...\n");
	while(1)
	{
		printf("1.Push\n2.Pop\n3.Display\n4.Minimum Element\n5.Exit\n");
		printf("Enter your choice");
		scanf("%d", &ch);
		switch(ch)
		{
			case 1 : push();
				 break;
			case 2 : pop();
				 break;
			case 3 : display();
				 break;
			case 4 : minElement();
				 break;
			case 5 : exit(1);
				 break;
			default :printf("Invalid choice");
		}
	
	}
	return 0;
}

void push()//Elements pushing into the stack
{
	struct node *ptr;
	int val;
	ptr = (struct node*)malloc(sizeof(struct node));
	if(ptr == NULL)
	{
		printf("Not able to push the element\n");
	}
	else
	{
		printf("Enter value:");
		scanf("%d",&val);
		if(head == NULL)
		{
			ptr->data = val;
			ptr -> next = NULL;
			head = ptr;
		}
		else
		{
			ptr -> data = val;
			ptr -> next = head;
			head = ptr;
		}
		printf("Item pushed into the stack\n");
	}
}

void pop()
{
	struct node *ptr;
	int item;
	if(head == NULL)

{
		printf("Stack is underflow\n");
	}
	else
	{
		item = head -> data;
		ptr = head;
		head = head->next;
		free(ptr);
		printf("Item is popped from stack\n");
	}
}

void display()
{
	struct node *ptr;
	ptr = head;
	if(ptr == NULL)
	{	
		printf("Stack is empty\n");
	}
	else
	{
		while(ptr!= NULL)
		{	
			printf("%d->\n", ptr->data);
			ptr = ptr -> next;
		}
	}
}

void minElement()
{
	struct node *current = head;
	int min;
	if(head == NULL)
	{
		printf("Stack is empty\n");
	}
	else
	{
		while(current != NULL)
		{
			if(min > current -> data)
			{
				min = current -> data;
			}
			current = current -> next;
		}
		printf("Minimum value of node of the linked list is:%d\n", min);
	}
}
