/*
* * NAME	:basic_program.c
* * DATE 	:27-06-2023
* *DESCRIPTION  :This is program to prints hello world
* */

#include<stdio.h>

int main()
{
	printf("Hello");
	printf("World!");
	printf("\n");
	printf("Hi\c");
	return 0;
}
