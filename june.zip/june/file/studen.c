#include<stdio.h>
#include<stdlib.h>

int main()
{
	char name[50];
	int marks;
	int n;
	printf("Enter number of students:");
	scanf("%d",&n);
	FILE *fptr;
	fptr = fopen("Student.txt","w");
	if(fptr == NULL)
	{
		perror("Error:");
	}
	for(int i = 0; i < n; i++)
	{
		printf("Enter student name:");
		scanf("%s",name);

		printf("Enter marks:");
		scanf("%d",&marks);

		fprintf(fptr,"name:%s,marks:%d\n",name,marks);
	}
	fclose(fptr);
	return 0;
}

