#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>

struct Employee
{
	char name[20];
	int id;
	float sal;
};

int main()
{
	struct Employee emp;
	FILE *fp1;
	fp1 = fopen("Emp.txt", "r");
	printf("NAME\tID\tSAL\n");

	while(fscanf(fp1, "%s %d %f",emp.name,&emp.id,&emp.sal)!=EOF)
	{
		printf("%s\t %d\t%f\n",emp.name,emp.id,emp.sal);
	}
	fclose(fp1);
	return 0;
}
