#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>

struct Employee
{
	char name[20];
	int id;
	float sal;
};

int main()
{
	struct Employee emp;
	FILE *fp;
	int n;
	fp = fopen("Emp1.txt","rb");
	if(fp == NULL)
	{
		printf("Unable to open the file");
		exit(1);
	}
	printf("Enter the record numberd to be read:");
	scanf("%d", &n);
	fseek(fp,(n-1)*sizeof(emp),0);//skip n-1 records
	fread(&emp,sizeof(emp),1,fp);//read nth record
	printf("%s\t %d\t %f",emp.name,emp.id,emp.sal);
	fclose(fp);
	return 0;
}

		

