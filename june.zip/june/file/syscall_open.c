#include<stdio.h>
#include<fcntl.h>
#include<stdlib.h>
#include<unistd.h>

int main()
{
	int fd;//intialization of file descriptor
	fd = open("abc.txt", O_CREAT, 0644);//creating of file using open systemcall 
	if(fd < 0)
	{
		perror("Error: ");//error
		exit(1);
	}
	printf("The value of O_CREAT:%d\n",O_CREAT);
	printf("The value of O_RDWR:%d\n", O_RDWR);
	close(fd);
	return 0;
}
