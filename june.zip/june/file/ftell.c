#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>

struct Employee
{
	char name[20];
	int id;
	float sal;
};

int main()
{
	struct Employee emp;
	FILE *fp;
	fp = fopen("Emp1.txt","rb");
	if(fp == NULL)
	{
		printf("Unable o open the file");
		exit(1);
	}
	printf("Position pointer in the beginining ->%ld\n",ftell(fp));
	while(fread(&emp,sizeof(emp),1,fp) == 1)
	{
		printf("Position of fp is:%ld\n",ftell(fp));
		printf("%s\t%d\t%f\n",emp.name,emp.id,emp.sal);
	}
	printf("The size of bytes is:%ld",ftell(fp));
	fclose(fp);
	return 0;
}
		
