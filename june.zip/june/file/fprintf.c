#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdlib.h>

int main()
{
	FILE *fp;
	fp = fopen("C:\\data.txt", "w");
	char name[20];
	int id;
	if(fp == NULL)
	{
		printf("Unable to open the file");
		exit(1);
	}
	printf("Enter name and id:");
	scanf("%s %d", name, &id);
	fprintf(fp, "My name is %s and id is %d", name, id);
	fclose(fp);
	return 0;
}
