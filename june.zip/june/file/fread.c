#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

struct Employee
{
	char name[20];
	int id;
	float sal;
};

int main()
{
	struct Employee emp;
	FILE *fp;
	fp = fopen("Emp1.txt", "rb");
	int n;
	if(fp == NULL)
	{
		printf("Unable to open the file");
		exit(1);
	}
	printf("NAME\tID\tSAL\n");
	while(fread(&emp,sizeof(emp),1,fp) == 1)
	{
		printf("%s\t%d\t%f\n",emp.name,emp.id,emp.sal);
	}

	fclose(fp);
	
	

	return 0;
}

