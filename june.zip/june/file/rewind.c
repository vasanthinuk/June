#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>

struct Employee
{
	char name[20];
	int id;
	float sal;
};

int main()
{
	struct Employee emp;
	FILE *fp;
	fp = fopen("Emp1.txt","rb");
	if(fp == NULL)
	{
		printf("Unable to open the file");
		exit(1);
	}
	printf("Position of file pointer ->%ld\n",ftell(fp));
	fseek(fp,0,2);
	printf("Position of file pointer ->%ld\n",ftell(fp));
	rewind(fp);
	printf("Position of file pointer ->%ld\n",ftell(fp));
	fclose(fp);
	return 0;
}

