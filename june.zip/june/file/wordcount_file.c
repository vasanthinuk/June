#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdlib.h>

#define MAX 100

int main()
{
	FILE *fp;
	char str[MAX];
	fp = fopen("file1.txt","w+");

	if(fp == NULL)
	{
		printf("Unable to open the file");
		exit(1);
	}
	else
	{
		while(fgetc(fp) != EOF)
		{
			


