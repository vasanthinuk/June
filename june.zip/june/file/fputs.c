#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

int main()
{
	FILE *fptr;
	char str[100];
	fptr = fopen("str.txt", "w");
	if(fptr == NULL)
	{
		printf("Unable to open the file:");
		exit(1);
	}
	//printf("Enter the text:\n");
	//printf("Ctrl+d in unix");
	while((fgets(str,100,fptr))!= NULL)
	{
		printf("Enter the txt:");
		fputs(str,fptr);
	}
	fclose(fptr);
	return 0;
}

