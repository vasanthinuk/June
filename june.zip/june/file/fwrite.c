#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

struct Employee
{
	char name[20];
	int id;
	float sal;
};

int main()
{
	struct Employee emp;
	FILE *fp;
	fp = fopen("Emp1.txt", "wb");
	int n;
	if(fp == NULL)
	{
		printf("Unable to open the file");
		exit(1);
	}
	printf("Enter no. of employee details to be entered:");
	scanf("%d", &n);
	for(int i = 0; i < n; i++)
	{
		printf("Enter name:");
		scanf("%s", emp.name);
		printf("Enter id:");
		scanf("%d", &emp.id);
		printf("Enter sal:");
		scanf("%f", &emp.sal);
		fwrite(&emp, sizeof(emp),1, fp);
	}
	fclose(fp);
	
	

	return 0;
}

