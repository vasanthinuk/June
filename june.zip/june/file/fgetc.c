#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main()
{
	FILE *fptr;
	char ch;
	fptr = fopen("char.txt","r");

	if(fptr == NULL)
	{
		printf("Unable to open the file");
		exit(1);
	}
	else
	{
		//printf("Enter the text:\n");
		while((ch = fgetc(fptr)) != EOF)
		{
			printf("%c",ch);
		}
	}
	fclose(fptr);
	return 0;
}


