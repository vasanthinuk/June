#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>

int main()
{
	FILE *fp;
	char str[100];
	fp = fopen("str.txt", "r");
	if(fp == NULL)
	{
		printf("Unable to open the file");
		exit(1);
	}
	while((fgets(str,100,fp)) != NULL)
	{
		puts(str);
	}
	fclose(fp);
	return 0;
}
