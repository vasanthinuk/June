#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

struct Employee
{
	char name[20];
	int id;
	float sal;
};

int main()
{
	struct Employee emp;
	FILE *fp;
	fp = fopen("Emp.txt", "w");
	int n;
	printf("Enter no. of employee details to be entered:");
	scanf("%d", &n);
	for(int i = 0; i < n; i++)
	{
		printf("Enter name:");
		scanf("%s", emp.name);
		printf("Enter id:");
		scanf("%d", &emp.id);
		printf("Enter sal:");
		scanf("%f", &emp.sal);
		fprintf(fp, "%s\t %d\t %f\n", emp.name,emp.id,emp.sal);
	}
	fclose(fp);
	
	

	return 0;
}

