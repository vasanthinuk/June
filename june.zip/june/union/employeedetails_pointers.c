#include<stdio.h>
#include<string.h>

union Employee
{
	int id;
	char name[20];
};

int main()
{
	union Employee emp;
	emp.id = 10;
	printf("%d\n",emp.id);//In union only one variable can access at a time

	strcpy(emp.name, "Vasanthi");
	printf("%s\n",emp.name);
	printf("The size of union is : %ld ", sizeof(emp));
}
