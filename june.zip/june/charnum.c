#include<stdio.h>

int main(void)
{
	char a=10;
	char c='A';
	printf("%d\n",a);
	printf("%c\n",c);

}

