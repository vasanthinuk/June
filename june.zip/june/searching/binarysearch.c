
#include<stdio.h>
int binarysearch(int*,int,int,int);

int main()
{
	int arr[30];
	int n;
	int ele;
	int res;
	int temp;
	printf("Enter number of elements to be entered:");
	scanf("%d",&n);
	for(int i = 0;i < n; i++)
	{
		scanf("%d",&arr[i]);
	}
	for(int i =0;i < n;i++)
	{
		for(int j = i+1;j<n;j++)
		{
			if(arr[i]>arr[j])
			{
				temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
	}
		
	printf("The elements in the array are:");
	for(int i = 0; i < n; i++)
	{
		printf("%d  ",arr[i]);
	}
	printf("\n");
	printf("Enter the element to be searched:");
	scanf("%d",&ele);
	res = binarysearch(arr,0,n-1,ele);
	if(res ==-1)
	{
		printf("Element not found\n");
	}
	else
	{
		printf("Element is found at index %d",res);
	}
	return 0;
}

int binarysearch(int* arr,int low,int high,int ele)
{
	
	int mid;
	while(low <= high)
	{
		mid = low+(high-low)/2;
		if(arr[mid]==ele)
		{
			return mid;
		}
		if(arr[mid]<ele)
		{
			low = mid+1;
		}
		else
		{
			high = mid -1;
		}
	}
	return -1;
}
