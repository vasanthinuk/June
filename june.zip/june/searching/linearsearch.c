/*
Name        : linearsearch.c
Description : used for small amounts of data and for unsorted lists
*/

#include<stdio.h>
#include<stdlib.h>

int linearsearch(int*,int,int);
int main()
{
	int arr[100];
	int n;
	int ele;
	int res;
	printf("Enter number of elements to be entered into an array:");
	scanf("%d",&n);
	for(int i = 0; i < n; i++)
	{
		scanf("%d",&arr[i]);//reading of array elements
	}
	printf("The elements in array are:");
	for(int i = 0; i < n; i++)
	{
		printf("%d ",arr[i]);//printing the array elements in an array
	}
	printf("\n");
	printf("Enter the element to be searched:");
	scanf("%d",&ele);
	res = linearsearch(arr,n,ele);
	if(res != -1)
	{
		printf("The searching element %d is found at index at :%d\n",ele,res);
	}
	else
	{
		printf("The searching value is not present in the array\n");
	}

	return 0;
}

int linearsearch(int* arr,int n,int ele)
{
	for(int i = 0;i<n;i++)
	{
		if(arr[i] == ele)
		{
			return i;
		}
	}
	return -1;
}
