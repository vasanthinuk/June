#include<stdio.h>

int main()
{
	int num;
	int r;
	int rev = 0;
	printf("Enter a number");
	scanf("%d",&num);
	while(num>0)
	{
		r = num%10;
		rev = rev *10+ r;
		num = num/10;
	}
	printf("%d",rev);
	return 0;
}

