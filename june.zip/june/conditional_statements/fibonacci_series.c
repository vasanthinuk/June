#include<stdio.h>

int main()
{
	int f0 ;
	int f1 ;
	int f2;
	int n;
	printf("Enter the term");
	scanf("%d",&n);
	f0 = 0;
	f1 = 1;
	for(int i = 1; i<n;i++)
	{	
		//f0 = 0;
		//f1 = 1;
		f2 = f0 + f1;
		printf("The fibonacci series:%d\n", f2);
		f0 = f1;
		f1 = f2;
	}
	printf("\n");
	return 0;
}


		
