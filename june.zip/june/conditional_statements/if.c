#include<stdio.h>

void fun(int, int);

int main()
{	
	int a;
	int b;
	printf("Enter a number");
	scanf("%d",&a);
	printf("Enter a number");
	scanf("%d",&b);
	fun(a,b);
	return 0;
}

void fun(int x,int y)
{
	if(x>y)
	{
		printf("Larger number = %d  smaller number =%d\n",x,y);
	}
	else
	{

		printf("Larger number = %d  smaller number =%d\n",y,x);
	}
}
