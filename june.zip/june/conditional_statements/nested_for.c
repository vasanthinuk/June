#include<stdio.h>

int main()
{
	int n;
	printf("Enter a number");
	scanf("%d",&n);
	for(int i = 0;i<n;i++)
	{
		printf("i =%d\n",i);
		for(int j = 0;j<=5;j++)
		{
			printf("j =%d\t",j);
		}
		printf("\n");
	}
	return 0;
}

