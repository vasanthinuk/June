#include<stdio.h>

int main()
{
	int num;
	int n;
	int sum = 0;
	int rem;
	printf("Enter a number");
	scanf("%d",&num);
	n = num;

	while(n > 0)
	{
		rem = n%10;
		sum = sum + (rem*rem*rem);
		n = n/10;
	}
	
	if(n == sum)
	{
		printf(" armstrong number:%d\n", n);
	}
	else
	{
		printf("The number is not an armstrong number:%d",n);
	}
	return 0;
}
