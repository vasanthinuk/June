#include<stdio.h>

int main()
{
	int num;
	int count = 0;
	printf("Enter a number");
	scanf("%d",&num);
	do
	{
		num = num/10;
		count=count+1;
	}
	while(num!=0);
	printf("The count of digits of a number:%d\n", count);
	return 0;
}

