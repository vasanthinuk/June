#include<stdio.h>

int main()
{
	int a;
	int sum = 0;
	int rem;
	printf("Enter a number");
	scanf("%d",&a);
	while(a>0)
	{
		rem = a%10;
		sum = sum + rem;
		a = a/10;
	}

	printf("The sum of digits:%d\n",sum);
	return 0;
}

