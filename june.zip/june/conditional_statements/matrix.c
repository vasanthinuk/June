#include<stdio.h>

int main()
{
	int row;
	int col;
	int a[row][col];
	printf("Enter no. of rows");
	scanf("%d",&row);
	printf("Enter no. of columns");
	scanf("%d",&col);
	for(int i =0;i<=row;i++)
	{
		int val;
		printf("enter value");
		scanf("%d",&val);
		for(int j=0;j<=col;j++)
		{
			int val1;
			printf("Enter value");
			scanf("%d",&val1);
			//printf("%d ",a[i][j]);
		}
	}
	printf("\n");
}


