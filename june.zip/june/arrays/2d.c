#include<stdio.h>

int main()
{
	int arr[2][3] = { {1,2,3}, {4,5,6}};
	int j=0;
	for(int i = 0; i < 2; i++)
	{
		printf("Address  of %dth array:%u, %u\n",i,arr[i], *(arr+i));
		for(j = 0; j < 3; j++)
		{
			printf("The elements are:%u, %u\n", arr[i][j], *(*(arr+i)+j));
		}
		printf("\n");
	}
	return 0;
}
		
	
