#include<stdio.h>

int main()
{
	int arr[50];
	int n;
	int *ptr;
	printf("Enter no. of elements to be entered:");
	scanf("%d",&n);
	ptr = arr;
	for(int i = 0; i < n; i++)
	{
		
		//scanf("%d",&arr[i]);
		scanf("%d",(ptr+i));
	}
	for(int i = 0; i < n; i++)
	{
		//printf("%d ", arr[i]);
		printf("%d ",*(ptr + i));
	}
	return 0;
}

