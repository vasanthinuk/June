#include<stdio.h>

#define MAX 50

int main()
{
	char* arr[5][20] = {NULL};
	//char *ptr = NULL;
	//ptr = &arr;
	char **ptr1 = NULL;
	ptr1 = arr;
	for(int i = 0; i < 5; i++)
	{
		printf("Enter names:");
		scanf("%s",*ptr1);
	}
	printf("The names are:\n");
	for(int i = 0; i < 5; i++)
	{
		printf("%s\n", *(ptr1+i));
	}
	
	return 0;
}
