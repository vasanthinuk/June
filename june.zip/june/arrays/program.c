#include<stdio.h>

#define MAX 50

int main()
{
	char arr[5][20];
	for(int i = 0; i < 5; i++)
	{
		printf("Enter names:");
		scanf("%s",arr[i]);
	}
	printf("The names are:\n");
	for(int i = 0; i < 5; i++)
	{
		printf("%s\n", *(arr+i));
	}
	
	return 0;
}
