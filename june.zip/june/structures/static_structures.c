#include<stdio.h>

extern struct A
{
	int a;
	char b[2];
};

int main()
{
	struct A e;
	printf("Enter a value");
	scanf("%d", &e.a);
	printf("Enter a character");
	scanf("[^%s\n]", e.b);
	printf("The value is:%d\n", e.a);
	printf("The character is:%s\n",e.b);
	return 0;
}


