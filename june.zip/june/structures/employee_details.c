#include<stdio.h>
#include<string.h>

struct Employee
{
	int emp_id;
	char emp_name[20];
	float emp_salary;
	char emp_gender[2];
};

int main()
{
	int n;
	printf("Enter no. of employee details to be entered");
	scanf("%d",&n);
	struct Employee emp[n];
	for(int i = 0; i < n; i++)
	{
		printf("Enter employee id:");
		scanf("%d",&emp[i].emp_id);
		printf("Enter employee name:");
		scanf("%s",emp[i].emp_name);
		printf("Enter employee salary:");
		scanf("%f",&emp[i].emp_salary);
		printf("Enter gender:");
		scanf("%s",emp[i].emp_gender);
	}
	printf("The employee details are:\n");
	for(int i = 0; i < n; i++)
	{
		printf("\nemp_id:%d\t emp_name:%s\t emp_salary:%f\t emp_gender:%s\n",emp[i].emp_id,emp[i].emp_name,emp[i].emp_salary,emp[i].emp_gender);
	}
	return 0;
}
