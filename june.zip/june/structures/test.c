#include<stdio.h>
#include<string.h>

struct A
{
	int a;
	char b;
	float c;
}e = {10, 'A',23.6};

int main()
{
	//struct A e;
	printf("%d %c %f", e.a,e.b,e.c);
	return 0;
}

