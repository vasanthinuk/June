#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct Student
{
	char name[20];
	int id;
	int ph;
};

int main()
{
	struct Student *ptr;
	int n;
	printf("Enter number how many details of students to be entered:");
	scanf("%d", &n);

	ptr = (struct Student*)malloc(sizeof(struct Student)*n);
	for(int i = 0;i < n;i++)
	{
		printf("Enter name:");
		scanf("%s", (ptr+i)->name);
		printf("Enter id:");
		scanf("%d", &(ptr+i)->id);
		printf("Enter Phone number:");
		scanf("%d", &(ptr+i)->ph);
	};
	printf("Displaying information of student details:\n");

	for(int i = 0; i < n;i++)
	{
		printf("%s\t%d\t%d\n", (ptr+i)->name,(ptr+i)->id,(ptr+i)->ph);
	}
	return 0;
}
