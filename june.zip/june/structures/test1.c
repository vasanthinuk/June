#include<stdio.h>
#include<string.h>
#pragma pack(1)
union A
{
	int a ;
	char b ;
};

int main()
{
	union A e;

//	printf("enter the gender \n female = 0\n male = 1\n other = 2\n");
//	scanf("%d",&num);
//	scanf("%d",&e.a);
//	e.a = num;
	printf("Enter value\n");
	scanf("%d",&e.a);
	printf("char %c\n",e.b);
	printf("int %d\n",e.a);
	printf("%d\n",sizeof(e));
	return 0;
}

