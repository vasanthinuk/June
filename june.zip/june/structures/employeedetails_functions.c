#include<stdio.h>
#include<string.h>

struct Employee
{
	char empName[20];
	int empId;
	float empSalary;
};

void display(struct Employee);

int main()
{
	int n;
	printf("How many number of employee details to be entered");
	scanf("%d",&n);
	struct Employee  e[n];
	for(int i = 0; i < n; i++)
	{
		printf("Enter Employee name: ");
		scanf("%s", e[i].empName);
		printf("Enter Employee ID: ");
		scanf("%d", &e[i].empId);
		printf("Enter employee Salary: ");
		scanf("%f", &e[i].empSalary);
	}
	for(int i = 0; i < n; i++)
	{
		display(e[i]);
	}
	return 0;
}

void display(struct Employee emp)
{
	printf("Employee name :%s\n ",emp.empName);
	printf("Employee id   :%d\n", emp.empId);
	printf("Employee salary :%f\n",emp.empSalary);
}


