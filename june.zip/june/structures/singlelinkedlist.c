#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct node
{
	int data;
	struct node *next;
};

void printLinkedList(struct node *);

int main()
{
	struct node *head;
	struct node *one = NULL;
	struct node *two = NULL;
	struct node *three = NULL;
	one = malloc(sizeof(struct node));
	two = malloc(sizeof(struct node));
	three = malloc(sizeof(struct node));

	one -> data = 1;
	two -> data = 2;
	three -> data = 3;

	//connected nodes
	one ->next = two;
	two ->next = three;
	three ->next = NULL;

	head = one;

	printLinkedList(head);
	return 0;
}

void printLinkedList(struct node *ptr)
{
	while(ptr != NULL)
	{
		printf("%d\n", ptr ->data);
		ptr = ptr ->next;
	}
}
