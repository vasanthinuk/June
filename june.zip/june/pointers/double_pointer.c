/*
* Name		: double_pointer.c
* Description	: To print the names on the screen using double pointers
* Date    	: 3-07-2023
*/

#include<stdio.h>

int main()
{
	char *ch[] = {"vasu", "nukala", "harini", "sowmya", "sivarani"};
	int n;
	char **ptr = ch;
	/*printf("Enter number of names to be entered");
	scanf("%d",&n);*/
	/*for(int i = 0;i<n;i++)
	{
		printf("Enter name:");
		scanf("%s", *(ch+i));
	}*/
	for(int i = 0; i < 5; i++)
	{
		printf("%s\n",*(ptr+i));
	}
	return 0;
}
