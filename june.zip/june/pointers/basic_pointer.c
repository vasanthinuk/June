#include<stdio.h>

int main()
{
	int num=12;
	float sal=1234.00;
	char name[20]="vasu";
	/*printf("Enter a number");
	scanf("%d",&num);
	printf("Enter salary");
	scanf("%f",&sal);
	printf("Enter a name");
	scanf("%s",&name);*/
	printf("Value of num =%d , address =%u\n",num,&num);
	printf("Value of sal =%f, address=%u\n",sal,&sal);
	printf("Value of name=%s,address=%u\n",name,&name);
	return 0;
}
