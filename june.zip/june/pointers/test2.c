#include<stdio.h>
#include<stdlib.h>

int main()
{
	//char ch[20];
	
	char *ptr[5] = {NULL};
	
	for(int i = 0; i < 5; i++) {
		ptr[i] = (char*)malloc(10*sizeof(char));
		printf("enter a name\n");
		fgets(ptr[i], 10, stdin);
	}
	char **ptr1 = ptr;
	for(int  i = 0; i < 5; i++) {
		printf("The string2 is:%s", *(ptr1 + i));
	}
	for(int i = 0;i < 5; i++)
	{
		free(ptr[i]);
		ptr[i] = NULL;
	}
	return 0;
}


