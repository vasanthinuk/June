/*
* Name		: double_pointer.c
* Description	: To print the names on the screen using double pointers
* Date    	: 3-07-2023
*/

#include<stdio.h>

int main()
{
	//char *ch[] = {"vasu", "nukala", "harini", "sowmya", "sivarani"};
	char ch[200];
	char *ptr = &ch;
	//char *ptr = &ch;
	char **ptr1 = &ptr;
	
	//char **ptr = ch;


	for(int i = 0;i<9;i++)
	{
		printf("Enter name:");
		scanf("%s", (ptr1+i));
	}
	for(int i = 0; i < 9; i++)
	{
		printf("%s\n",(ptr1+i));
	}
	return 0;
}
