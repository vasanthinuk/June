#include<stdio.h>

int main()
{
	int a =10;
	char ch = 'A';
	float f = 1234.5678;
	double d = 123.45678897507;
	int *ip = &a;//pointer declaration and assigning the address of that variable
	char *cp = &ch;
	float *fp = &f;
	double *dp = &d;
	printf("sizeof ip =%d , sizeof (*ip) =%d\n", sizeof(ip),sizeof(*ip));//ip gives pointer size, *ip gives sizeof datatype
	printf("sizeof cp =%d , sizeof (*cp) =%d\n", sizeof(cp),sizeof(*cp));
	printf("sizeof fp =%d , sizeof (*fp) =%d\n", sizeof(fp),sizeof(*fp));
	printf("sizeof dp =%d , sizeof (*dp) =%d\n", sizeof(dp),sizeof(*dp));
	return 0;
	//sizeof pointers is same for all data types

}
