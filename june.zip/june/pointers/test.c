#include<stdio.h>

int main()
{
	char ch[20];
	char *ptr=NULL;
	ptr=ch;
	char **ptr1=NULL;
	ptr1 = &ptr;
	printf("Enter string");
	scanf("%s",ch);
	printf("The string:%s", *ptr1);
	return 0;
}


