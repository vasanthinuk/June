#include<stdio.h>

int main()
{
	int age = 30;
	int *ip;
	char name[20] = "Vasanthi";
	char *cp;
	ip = &age;
	cp = &name;
	//ip = age;
	//cp = name;
	printf("The value of ip is:%d\n", ip);//address
	printf("The value of cp is:%d\n", cp);
	printf("The address of age is:%u\n",&ip);
	printf("The address of name is:%u\n",&cp);
	printf("The value of age is:%d %d %d\n",age,*ip,*(&age));//values
	printf("The value of names is:%s  %s\n", name, *(&name));
	return 0;
}

