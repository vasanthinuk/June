#include<stdio.h>

int main()
{
	int a; 
	int *ptr;

	a = 10;
	printf("The value of a is:%d\n", a);
	printf("The address of a is:%p\n",&a);

	ptr = &a;
	printf("The address of ptr is:%p\n", ptr);
	printf("The value of ptr is:%d\n", *ptr);

	a = 12;
	printf("The address of ptr is:%p\n", ptr);
	printf("The value of ptr is:%d\n", *ptr);

	*ptr = 25;
	printf("The address of ptr is:%p\n", &a);
	printf("The value of ptr is:%d\n", a);
	return 0;
}
