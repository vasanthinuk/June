#include<stdio.h>

int main()
{
	int a = 10;
	int *b = &a;
	int **c = &b;
	printf("Value of a is:%d\n",a);
	printf("Value of b is:%d\n",*b);
	printf("Value of c is:%d\n",**c);
	printf("Value of a is:%d\n",*(&a));

	printf("Address of a is:%p\n",&a);
	printf("Address of b is:%p\n",b);
	printf("Address of c is:%p\n",*c);
	printf("Address of b is:%p\n",&b);
	printf("Address of c is:%p\n",&c);
	return 0;
}
