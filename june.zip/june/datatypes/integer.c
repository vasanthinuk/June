#include<stdio.h>

int main()
{
	int a;
	printf("Enter a character:");
	scanf("%c", &a);
	printf("The number is:%c", a);
	return 0;
}

