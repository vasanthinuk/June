/***
* * Name	: macro.c
* * Description : This program is used macro without defining it
* */

#include<stdio.h>

float pi=3.14;

int main(void) //main function
{
	//float pi = 3.14;
	int r;
	printf("Enter the radius to a circle:");
	scanf("%d", &r);
	float area;
	float circumference;
	area = pi * r * r;
	circumference = 2 * pi *r;
	printf("The area of circle is:%f\n", area);
	printf("The circumeference of circle is:%f\n", circumference);
	printf("The current line is:%d\n", __LINE__);
	printf("The date is:%s\n", __DATE__);
	return 0;
}
	
