#include<stdio.h>

int main()
{
	unsigned char ch;
	printf("Enter a number");
	scanf("%d", &ch);
	printf("The character is :%c", ch);
	return 0;
}


