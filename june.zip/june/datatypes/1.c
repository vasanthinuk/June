#include<stdio.h>

int main()
{
	printf("Macro is :%d", PI);
	return 0;
}

