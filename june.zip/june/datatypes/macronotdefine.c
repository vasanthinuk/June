#include<stdio.h>

int main()
{
	printf("Macro is:%f",CH);
	return 0;
}

