#include<stdio.h>

int main(void)
{
	char num;
	for(num=97;num<=122;num++)
	{
		printf("%c\n",num);
	}
	return 0;
}
