#include<stdio.h>

int str_cmp(char *, char *);

int main()
{
	char str1[20];
	char str2[20];
	int c;
	printf("Enter the string1:");
	fgets(str1, 20, stdin);
	printf("Enter the string2:");
	fgets(str2, 20, stdin);
	c = str_cmp(str1, str2);
	printf("%d",c);
	return 0;

}

int str_cmp(char *s1, char *s2)
{
	while(*s1 != '\0' && *s2 != '\0' && *s1 == *s2 )
	{
		/*if(*str1 == *str2)
		{
			str1++;
			str2++;
			return 0;
		}*/
		s1++;
		s2++;
		if(*s1 == *s2)
		{
			return 0;
		}
		else
		{
			return(*s1 - *s2);
		}
	}
}
