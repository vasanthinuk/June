#include<stdio.h>
#include<string.h>
#include<stdlib.h>

char *strcopy(char *dest,const char *src,int n);

int main()
{
	char *str = NULL;
	char *str1 = NULL;
	int  n;
	str = (char *)malloc(sizeof(char));
	str1 = (char*)malloc(sizeof(char));
	printf("Enter the string:");
	fgets(str, 50,stdin);
	str[strlen(str)-1] = '\0';
	printf("Enter n number of bits to be copied:");
	scanf("%d", &n);
	printf("The result is:%s", strcopy(str1,str,n));
	free(str);
	free(str1);
	return 0;
}

char *strcopy(char *dest, const char *src,int n)
{
	char *ptr;
	ptr = dest;
	while(*src && n--)
	{
		*dest = *src;
		src++;
		dest++;
	}
	*dest = '\0';
	return ptr;
}
