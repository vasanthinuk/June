#include<stdio.h>
#include<string.h>
#include<stdlib.h>

char *strcpy(char *,const char *);

int main()
{
	char *str = NULL;
	char *str1 = NULL;
	char res;
	str = (char *)malloc(sizeof(char));
	str1 = (char*)malloc(sizeof(char));
	printf("Enter the string:");
	fgets(str, 50,stdin);
	str[strlen(str)-1] = '\0';
	
	printf("The result is:%s", strcpy(str1,str));
	free(str);
	free(str1);
	return 0;
}

char *strcpy(char *dest, const char *src)
{
	char *ptr;
	ptr = dest;
	while(*src != '\0')
	{
		*dest = *src;
		src++;
		dest++;
	}
	return ptr;
}
