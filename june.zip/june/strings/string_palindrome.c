#include<stdio.h>
#include<string.h>

int main()
{
	char str[100];
	int count = 0;
	printf("Enter string:");
	scanf("%s",str);
	int n ;
	n = strlen(str)-1;
	int i = 0;
	int j = n;
	for(i,j; i<j; i++,j--)
	{	
		if(str[i] == str[j])
		{
			count = 0;
		}
		else
		{
			count = 1;
			break;
		}
	}
	if(count == 0)
	{
		printf("String is palindrome");
	}
	else
	{
		printf("String is not palindrome");
	}
	return 0;
}

