#include<stdio.h>

int main()
{
	char *str = "vasanthi" ;
	/*printf("Enter the string:");
	scanf("%s", str);*/
	while(*str != '\0')
	{
		printf("Character is :%c\n", *str);
		printf("address is :%u\n", str);
		str++;
	}
	return 0;
}
