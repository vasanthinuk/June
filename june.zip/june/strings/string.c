#include<stdio.h>

int main()
{
	char str[50];
	printf("Enter string:");
	scanf("%[^\n]s", str);
	printf("The entered string is : %s", str);
	return 0;
}
