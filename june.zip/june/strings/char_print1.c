#include<stdio.h>
#include<string.h>

void char_print(char *);


int main()
{
	
	char str[30];
	printf("Enter the string:");
	fgets(str, 20, stdin);
	str[strlen(str) -1] = '\0';
	char_print(str);
	return 0;
}

void char_print(char *str)
{

	while(*str != '\0')
	{
		printf("Character is :%c\n", *str);
		printf("address is :%u\n", str);
		str++;
	}
}
