#include<stdio.h>

int main(void)
{
	float x=10.8;
	float y=15.7;
	printf("Addition of x & y is :%f\n", (x+y));
	printf("Subtraction of x & y is :%f\n",(x-y));
	printf("Multiplication of x & y is:%f\n",(x*y));
	printf("Divison of x & y is:%f\n", (x/y));
	//printf("Modulo division of x & y is:%f\n", (x%y));
	return 0;
}
