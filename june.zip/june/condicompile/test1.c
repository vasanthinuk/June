/*
* * Name 	:test1.c
* *

#include<stdio.h>
#if 1

int main()
{
	printf("Hello");
	return 0;
}
