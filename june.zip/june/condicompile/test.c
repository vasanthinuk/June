/* 
* * Name	 : test.c
* * Description  : This program describes an erros in preprocessing
* */

#include<stdio.h>
#include "test.h"
#ifdef MAX 1

int main()
{
	printf("Hello World!");
	return 0;
}


