#include<stdio.h>

void fun();

int main()
{
	int X;
	fun();
	printf("Welcome to C programming\n");
	printf("X is:%d", X);
	return 0;
}

void fun()
{
	#define X 100
	//#ifdef X
	printf("X is:%d\n", X);
}
