#include<stdio.h>

#define SUN 2

int main()
{
	printf("Rays of SUN are coming through windows");
	return 0;
}

	
