#include<stdio.h>

#define DEBUG  0  //macro declaration

#if 1  //conditional compilation
int main()
{
	int x = 6;
	int y = 9;
	/*#if DEBUG
	{
		printf("x = %d, y = %d\n", x, y);
	}
	#endif*/
}
#endif


#if 0
int main()
{
	int x = 6;
	int y = 9;
	printf("x = %d, y = %d\n", x, y);
	return 0;
}
#endif
