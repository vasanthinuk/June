/*
* * NAME   	 : ifdef.c
* * Description  : This program is an example of ifdef conditional compilation
* * DATE   	 : 23-06-2023
* */

#include<stdio.h> //standard File Inclusion

#define X 10 //Macro declartion

int main()
{
	#ifdef X
	{
		printf("Hello World!\n");
	}
	#else
	{
		printf("Hi\n");
	}
	#endif
	return 0;
}



