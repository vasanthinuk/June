/*
* * Name 	: macro.c
* */

#include<stdio.h>

#define MAX=12;

int main()
{
	#ifdef 1
		printf("Hi");
	return 0;
}

