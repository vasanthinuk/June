#include<stdio.h>

int main()
{
	char ch;
	int num;
	printf("Enter a character:");
	scanf("%c",&ch);
	printf("Enter a number");
	scanf("%d",&num);
	num = num + ch;
	printf("The value is:%d\n",(int)ch);
	printf("The value of num is:%d", num);
	return 0;
}

