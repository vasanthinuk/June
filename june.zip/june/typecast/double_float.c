#include<stdio.h>

int main()
{
	float a;
	double num1;
	float b;
	printf("Enter a float value");
	scanf("%f",&a);
	printf("Enter b value");
	scanf("%f",&b);
	num1 = a/b;
	printf("The value of num is :%lf\n",num1);
	return 0;
}

