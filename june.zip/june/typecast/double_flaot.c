#include<stdio.h>

int main()
{
	double d;
	float num;
	printf("Enter double value");
	scanf("%lf",&d);
	num = d;
	printf("The value of num is:%f\n", num);
	return 0;
}

