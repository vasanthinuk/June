/*
* NAME		: int_float.c
* DESCRIPTION   : This program describes the conversion of integer to float data type
* DATE  	: 28-06-2023
* */

#include<stdio.h>

int main(void)
{
	int a;
	float f;
	printf("Enter a number");
	scanf("%d",&a);
	f=a;
	printf("The float value is:%f\n", f);
	return 0;
}


