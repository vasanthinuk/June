#include<stdio.h>

int main()
{
	int a;
	char ch;
	printf("Enter a number");
	scanf("%d",&a);
	ch = a;
	printf("The value of ch is:%c\n",ch);
	return 0;
}

