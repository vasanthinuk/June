#include<stdio.h>

int main()
{
	float num;
	int num1;
	printf("Enter float value");
	scanf("%f",&num);
	num1 = num;
	printf("The value of num1 is:%d\n",num1);
	return 0;
}


