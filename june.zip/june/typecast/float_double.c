#include<stdio.h>

int main()
{
	float num;
	double d;
	char ch;
	printf("Enter float value");
	scanf("%f",&num);
	d = num;
	printf("The double value is:%lf\n",d);
	ch = num;
	printf("The character value is:%c",ch);
	return 0;
}
