#include<stdio.h>

int main()
{
	int num;
	printf("Enter a number");
	scanf("%d",&num);
	printf("The value is:%d\n", num);
	printf("The value is:%f\n",(float)num);
	return 0;
}

