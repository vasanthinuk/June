/*
* Name         : 1.c
* Description  : Hello world 
*/

#include<stdio.h>

void main()
{
	int x = 10;
	printf("Hello World!\n");
	printf("The value of x is : %d\n", x);
	printf("The address of x is : %#x\n", &x);
}

